import socket

def dns_lookup():
    while True:
        print("\nMenu:")
        print("1. URL to IP lookup")
        print("2. IP to URL lookup")
        print("3. Exit")
        choice = input("Enter your choice (1/2/3): ")

        if choice == '1':
            # URL to IP lookup
            url = input("Enter the URL: ")
            try:
                ip_address = socket.gethostbyname(url)
                print(f"The IP address for {url} is {ip_address}")
            except socket.gaierror:
                print("Invalid URL or DNS resolution failed.")
        
        elif choice == '2':
            # IP to URL lookup
            ip = input("Enter the IP address: ")
            try:
                hostname, _, _ = socket.gethostbyaddr(ip)
                print(f"The hostname for IP address {ip} is {hostname}")
            except socket.herror:
                print("Invalid IP address or no associated hostname found.")
        
        elif choice == '3':
            print("Exiting the program.")
            break
        
        else:
            print("Invalid choice. Please enter either '1', '2', or '3'.")

# Run the DNS lookup program
dns_lookup()
